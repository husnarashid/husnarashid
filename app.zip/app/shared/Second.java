package com.example.shared;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class Second extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        TextView users = (TextView) findViewById(R.id.user);
        TextView psw = (TextView) findViewById(R.id.pass);
        TextView fn = (TextView) findViewById(R.id.name);

        SharedPreferences view = getSharedPreferences("data", MODE_PRIVATE);
        String xxU =view.getString("userName", "");
        String xxP = view.getString("Password", "");
        String xxN = view.getString("Name", "");

        users.setText(xxU);
        psw.setText(xxP);
        fn.setText(xxN);

    }
}