package com.example.shared;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void save(View v){
        EditText x_u = (EditText) findViewById(R.id.u_inp);
        EditText x_p = (EditText) findViewById(R.id.p_inp);
        EditText x_name = (EditText) findViewById(R.id.fn_inp);

        SharedPreferences xxx = getSharedPreferences("data", MODE_PRIVATE);
        SharedPreferences.Editor edt = xxx.edit();

        edt.putString("userName", x_u.getText().toString());
        edt.putString("Password", x_p.getText().toString());
        edt.putString("Name", x_name.getText().toString());
        edt.commit();

        x_u.setText("");
        x_p.setText("");
        x_name.setText("");

        Toast.makeText(MainActivity.this, "Your data has been saved..", Toast.LENGTH_LONG).show();

    }

    public void retreive(View v){
        Intent x = new Intent(MainActivity.this, Second.class);
        startActivity(x);
    }

    public void clear(View v){

        SharedPreferences xxx = getSharedPreferences("data", MODE_PRIVATE);
        SharedPreferences.Editor edt = xxx.edit();

        edt.putString("userName", "");
        edt.putString("Password", "");
        edt.putString("Name", "");
        edt.commit();

    }

}